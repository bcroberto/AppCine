function verificarTitulo() {
    var lonTitulo=document.getElementsByTagName('input')[0].value;
    var color=document.getElementsByTagName('input')[0];
    if (lonTitulo.length<4) {
        color.style.backgroundColor="red";
        alert('El campo debe contener un mínimo de 4 caracteres');
    } else {
        color.style.backgroundColor="green";
    }
}
var genero=["Fantástico", "Histórico", "Documental"];
/*alert(genero[1]);*/
function agregarOption() {
    var campoSelect=document.getElementsByTagName("select")[0];
    for (i = 0; i < genero.length; i++) {
        var campoOption=document.createElement("option");
        //campoOption.value="opcion_"i;
        campoOption.innerHTML=genero[i];
        campoSelect.appendChild(campoOption);
    }
}
function validar() {
    var titulo=document.getElementById("titulo").value;
    var genero=document.getElementById("opciones").value;
    alert("Se va a registrar la película con título "+titulo+" y de género "+genero);
}